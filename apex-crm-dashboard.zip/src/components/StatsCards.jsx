const stats = [
  {
    label: "NEW LEADS",
    value: 38,
    change: "+12% vs last week",
    positive: true,
    dotColor: "bg-[#818CF8]",
    barColor: "bg-[#818CF8]",
    barWidth: "w-2/5",
    active: true,
  },
  {
    label: "CONTACTED",
    value: 29,
    change: "+4% vs last week",
    positive: true,
    dotColor: "bg-[#38BDF8]",
    barColor: "bg-[#38BDF8]",
    barWidth: "w-1/3",
    textColor: "text-[#38BDF8]",
    active: false,
  },
  {
    label: "QUALIFIED",
    value: 41,
    change: "+8% vs last week",
    positive: true,
    dotColor: "bg-[#34D399]",
    barColor: "bg-[#34D399]",
    barWidth: "w-1/2",
    active: false,
  },
  {
    label: "CLOSED WON",
    value: 16,
    change: "-2% vs last week",
    positive: false,
    dotColor: "bg-[#4ADE80]",
    barColor: "bg-[#4ADE80]",
    barWidth: "w-1/4",
    active: false,
  },
];

export default function StatsCards() {
  return (
    // Card component design
    <div className="grid grid-cols-4 gap-4 px-6 pt-5">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={`bg-white rounded-[14px] p-4 shadow-sm overflow-hidden border relative transition-all ${
            stat.active
              ? "border-[#4F46E5] ring-0.5 ring-[#4F46E5] shadow-lg"
              : "border-[#EDEDED] hover:border-[#4F46E5]"
          }`}
        >
          <div className={` h-1 rounded-full ${stat.dotColor} absolute top-0 left-0 right-0`}></div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-11 font-bold tracking-widest text-[#5A5A6E]">
              {stat.label}
            </p>
            <span className={`w-2 h-2 rounded-full ${stat.dotColor}`}></span>
          </div>

          <p className="text-[26px] font-bold text-graytext-300 mb-2">{stat.value}</p>

          <p
            className={`text-11 font-medium mb-4 flex items-center gap-1 ${
              stat.positive ? "text-[#16A34A]" : "text-[#DC2626]"
            }`}
          >
            <span>{stat.positive ? "↑" : "↓"}</span>
            {stat.change}
          </p>

          <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${stat.barColor} ${stat.barWidth}`}
            ></div>
          </div>

        </div>
      ))}
    </div>
  );
}
