import React, { useState, useEffect } from "react";
const InfoItem = ({ label, value }) => (
  <div>
    <p className="text-[13px] text-[#5A5A5A] mb-0.5">{label}</p>
    <p className="text-[13px] font-semibold text-black">{value || "NA"}</p>
  </div>
);

const ContactRow = ({ value, tag, icon }) => {
  const tagColors = {
    Home: "bg-[#F4F7F9] text-[#14567C]",
    Office: "bg-[#FFF7F3] text-[#EC712B]",
    Sales: "bg-[#E3E8FF] text-[#475ECE]",
    Accounts: "bg-[#1A648E]/10 text-[#14567C]",
  };
  return (
    <div className="flex items-center justify-between py-1 border-b border-[#F5F5F7] last:border-0 px-2">
      <div className="flex items-center gap-2.5">
        <span className="text-[12px] text-[#000]">{value}</span>
        {tag && (
          <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${tagColors[tag] || "bg-gray-100 text-gray-500"}`}>
            {tag}
          </span>
        )}
      </div>
      <button className="w-7 h-7 flex items-center justify-center rounded-full border border-[#EDEDED] bg-white hover:bg-gray-50 text-[#000]">
        {icon}
      </button>
    </div>
  );
};

const NoteCard = ({ author, time, content }) => (
  <div className="bg-white border border-[#EDEDED] rounded-xl ">
    <div className="flex items-center justify-between p-2 border-b border-[#EDEDED]">
      <div className="flex items-center gap-1.5">
        {/* Note icon */}
        <div className="bg-[#E59400]/10 rounded-full p-2">
          <img src="/src/assest/images/notes.svg" alt="Apex CRM" className="" />
        </div>
        <span className="text-[11px] text-[#262424] font-semibold">
          Note By <span className=" text-[#262424] font-regular">{author}</span>
        </span>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 text-[10px] text-[#272727]">
          <img src="/src/assest/images/book.svg" alt="Apex CRM" className="" />
          {time}
        </div>
        <button className="text-[#9898AD] hover:text-gray-600">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="5" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="12" cy="19" r="1" />
          </svg>
        </button>
      </div>
    </div>
    <p className="text-[11px] text-[#000000] leading-relaxed px-2 py-3">{content}</p>
  </div>
);

const LeadOffcanvas = ({ open, onClose, lead }) => {
  const [activeTab, setActiveTab] = useState("Notes");
  const [noteText, setNoteText] = useState("");

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => { setActiveTab("Notes"); }, [lead]);

  if (!lead) return null;

  const tabs = ["Notes", "Document", "Meeting"];

  const defaultNotes = [
    { author: "Lewis Neill", time: "Today  10:00 AM", content: "Builder with * company wants picture windows" },
    { author: "Lewis Neill", time: "Today  10:00 AM", content: "Builder with * company wants picture windows" },
    { author: "Lewis Neill", time: "Today  10:00 AM", content: "Builder with * company wants picture windows" },
    { author: "Lewis Neill", time: "Today  10:00 AM", content: "Builder with * company wants picture windows" },
  ];

  return (
    <>
      {/* off canvas component design */}
      <div
        className={`fixed inset-0 bg-black/20 z-40 transition-opacity duration-300 ${open ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        onClick={onClose}
      />

      <div
        className={`fixed top-0 right-0 h-full max-w-[1221px] w-full bg-[#F9F9F9] z-50 shadow-2xl flex flex-col transition-transform duration-300 ease-in-out overflow-auto ${open ? "translate-x-0" : "translate-x-full"
          }`}
      >
        <div className="flex items-center justify-between px-6 py-4">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-[14px] font-medium text-[#1A1A1A] hover:text-[#2D2D3A] transition-colors"
          >
            <img src="/src/assest/images/back.svg" alt="Apex CRM" className="" />
            Back
          </button>

        </div>

        <div className="px-6 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-[19px] font-semibold text-black">{lead.title || "Need doors and window for new project"}</h1>
            <span className="bg-[#FF1C1C] text-white px-3 py-1 rounded-full text-[13px] font-semibold">Awareness</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-1.5 text-[13px] text-[#000000] hover:text-[#2D2D3A] border border-[#F3F3F3] rounded-lg px-3 py-1.5 bg-white hover:bg-gray-50 transition-colors">

              Edit
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
              </svg>
            </button>
            <button className="flex items-center gap-1.5 text-[13px] font-semibold text-white bg-gradient-to-r from-[#0C1764] to-[#3341A4] hover:bg-[#16304F] rounded-lg px-4 py-3 transition-colors">
              Add Lead
              <img src="/src/assest/images/user.svg" alt="Apex CRM" className="" />

            </button>
          </div>
        </div>

        <div className="mx-4 mt-4 bg-white rounded-[10px] p-4 shadow-sm">
          {/* Avatar */}
          <div className="grid grid-cols-12">
            <div className="col-span-3 flex gap-3 line-after px-4">
              <div className="flex flex-col items-center gap-2 flex-shrink-0">
                <div
                  className="w-[93px] h-[93px] rounded-full flex items-center justify-center text-[18px] font-bold text-white flex-shrink-0 border border-1 border-[#fff] shadow-sm"
                  style={{ backgroundColor: lead.color || "#6366F1" }}
                >
                  {lead.repAvatar ? (
                    <img src={lead.repAvatar} alt={lead.name} className="w-full h-full rounded-full object-cover" />
                  ) : (
                    lead.initials
                  )}
                </div>
                <div className="flex gap-1.5">
                  <button className="w-7 h-7 flex items-center justify-center rounded-full border border-[#E0E0E0] bg-white hover:bg-gray-50 text-[#9898AD]">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                      <polyline points="22,6 12,13 2,6" />
                    </svg>
                  </button>
                  <button className="w-7 h-7 flex items-center justify-center rounded-full border border-[#EDEDED] bg-white hover:bg-gray-50 text-[#9898AD]">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.96a16 16 0 0 0 6 6l.92-.92a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.73 16.92z" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="flex flex-col justify-center min-w-[130px]">
                <p className="text-[17px] font-bold text-black">{lead.name}</p>
                <p className="text-[13px] text-[#1C1C1C] mt-0.5">
                  Value <span className="font-semibold text-[#FF5C5C]">${lead.value || "200.00"}</span>
                </p>
                <button className="mt-1.5 w-5 h-5 flex items-center justify-center text-[#9898AD] hover:text-gray-600">
                  <img src="/src/assest/images/calender.svg" alt="Apex CRM" className="" />
                </button>
              </div>
            </div>
            <div className="col-span-3 space-y-2 line-after px-4 flex flex-col justify-center">
              <InfoItem label="Lead company" value={lead.company || "Cathy Bernal - Teq Stones"} />
              <InfoItem label="Product Type Door" value={lead.productDoor || "S3000 Sliding Glass Door"} />
            </div>
            <div className="col-span-3 space-y-2 line-after px-4 flex flex-col justify-center">
              <InfoItem label="Customer Type" value={lead.customerType || "Home Owner"} />
              <InfoItem label="Product Type Window" value={lead.productWindow || "S900 Casement"} />
            </div>
            <div className="col-span-3 space-y-2 line-after px-4 flex flex-col justify-center">
              <InfoItem label="Assigned to:" value={lead.rep || "Violet Zellweger"} />
              <InfoItem label="Method" value={lead.method || "NA"} />
            </div>
          </div>
        </div>

        <div className="flex gap-4 mx-4 mt-4 flex-1 pb-4">

          <div className="w-[240px] flex-shrink-0 flex flex-col gap-4">
            <div className="bg-white rounded-[10px] shadow-sm  ">
              <div className="flex items-center justify-between mb-3 p-2 border-b border-[#F5F5F5]">
                <h3 className="text-[15px] font-bold text-[#000]">Contact info</h3>
                <button className="text-[#F59E0B] hover:opacity-75">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                  </svg>
                </button>
              </div>

              <p className="text-[12px] font-bold text-[#000] mb-1.5 px-2">Phone(s)</p>
              <ContactRow
                value="01759695661"
                tag="Home"
                icon={<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.96a16 16 0 0 0 6 6l.92-.92a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.73 16.92z" /></svg>}
              />
              <ContactRow
                value="01759695661"
                tag="Office"
                icon={<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.96a16 16 0 0 0 6 6l.92-.92a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.73 16.92z" /></svg>}
              />

              <p className="text-[11px] font-bold text-[#1E1E2D] mt-3 mb-1.5 px-2">Email(s)</p>
              <ContactRow
                value="client@demo.com"
                tag="Office"
                icon={<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>}
              />
              <ContactRow
                value="Sales@demo.com"
                tag="Sales"
                icon={<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>}
              />
              <ContactRow
                value="Accounts@demo.com"
                tag="Accounts"
                icon={<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>}
              />
            </div>

            <div className="bg-white rounded-[10px] shadow-sm">
              <h3 className="text-[13px] font-bold text-[#1E1E2D] p-2 border-b border-[#F5F5F5]">Other information</h3>
              {[
                { label: "Referred By", value: "NA" },
                { label: "Market Segment", value: "NA" },
                { label: "", value: "NA" },
                { label: "Contact Person", value: "NA" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2 px-2 ">
                  <span className="text-[12px] text-[#000]">{item.label}</span>
                  <span className="text-[13px] text-[#646464]">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 flex flex-col min-h-0">
            <div className="bg-white rounded-[10px] p-0 shadow-sm flex flex-col flex-1 min-h-0">
              <div className="flex border-b border-[#EDEDED] px-4">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex items-center gap-1.5 px-4 py-3 text-[13px] font-medium border-b-2 transition-colors ${activeTab === tab
                      ? "border-[#FCA93D] text-[#FCA93D]"
                      : "border-transparent text-[#606060] hover:text-[#6B6B80]"
                      }`}
                  >
                    {tab === "Notes" && (
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                      </svg>
                    )}
                    {tab === "Document" && (
                      <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_1_1807)">
                          <path d="M6.28941 8.00452C6.13777 8.00452 5.99234 8.06476 5.88512 8.17198C5.77789 8.27921 5.71765 8.42463 5.71765 8.57627C5.71765 8.72791 5.77789 8.87334 5.88512 8.98057C5.99234 9.08779 6.13777 9.14803 6.28941 9.14803H12.007C12.1586 9.14803 12.304 9.08779 12.4113 8.98057C12.5185 8.87334 12.5787 8.72791 12.5787 8.57627C12.5787 8.42463 12.5185 8.27921 12.4113 8.17198C12.304 8.06476 12.1586 8.00452 12.007 8.00452H6.28941ZM5.71765 10.8633C5.71765 10.7117 5.77789 10.5662 5.88512 10.459C5.99234 10.3518 6.13777 10.2915 6.28941 10.2915H12.007C12.1586 10.2915 12.304 10.3518 12.4113 10.459C12.5185 10.5662 12.5787 10.7117 12.5787 10.8633C12.5787 11.0149 12.5185 11.1604 12.4113 11.2676C12.304 11.3748 12.1586 11.4351 12.007 11.4351H6.28941C6.13777 11.4351 5.99234 11.3748 5.88512 11.2676C5.77789 11.1604 5.71765 11.0149 5.71765 10.8633ZM5.71765 13.1503C5.71765 12.9987 5.77789 12.8533 5.88512 12.746C5.99234 12.6388 6.13777 12.5786 6.28941 12.5786H8.57644C8.72808 12.5786 8.8735 12.6388 8.98073 12.746C9.08795 12.8533 9.14819 12.9987 9.14819 13.1503C9.14819 13.302 9.08795 13.4474 8.98073 13.5546C8.8735 13.6618 8.72808 13.7221 8.57644 13.7221H6.28941C6.13777 13.7221 5.99234 13.6618 5.88512 13.5546C5.77789 13.4474 5.71765 13.302 5.71765 13.1503Z" fill="#606060" />
                          <path d="M10.8636 0H4.57426C3.9677 0 3.38599 0.240954 2.95709 0.669855C2.52819 1.09876 2.28723 1.68047 2.28723 2.28703V16.0092C2.28723 16.6158 2.52819 17.1975 2.95709 17.6264C3.38599 18.0553 3.9677 18.2962 4.57426 18.2962H13.7224C14.3289 18.2962 14.9106 18.0553 15.3395 17.6264C15.7684 17.1975 16.0094 16.6158 16.0094 16.0092V5.14581L10.8636 0ZM10.8636 1.14351V3.43054C10.8636 3.88546 11.0443 4.32175 11.366 4.64342C11.6877 4.9651 12.1239 5.14581 12.5789 5.14581H14.8659V16.0092C14.8659 16.3125 14.7454 16.6033 14.531 16.8178C14.3165 17.0322 14.0257 17.1527 13.7224 17.1527H4.57426C4.27098 17.1527 3.98012 17.0322 3.76567 16.8178C3.55122 16.6033 3.43075 16.3125 3.43075 16.0092V2.28703C3.43075 1.98375 3.55122 1.69289 3.76567 1.47844C3.98012 1.26399 4.27098 1.14351 4.57426 1.14351H10.8636Z" fill="#606060" />
                        </g>
                        <defs>
                          <clipPath id="clip0_1_1807">
                            <rect width="18.2962" height="18.2962" fill="white" />
                          </clipPath>
                        </defs>
                      </svg>

                    )}
                    {tab === "Meeting" && (
                      <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.0041 5.22416C11.2291 4.99802 12.1569 3.92437 12.1569 2.63401C12.1569 1.17929 10.9776 0 9.52292 0C8.0936 0 6.93018 1.13847 6.88999 2.55807H8.1723C9.18401 2.55807 10.0041 3.37823 10.0041 4.38991V5.22416Z" fill="#606060" />
                        <path d="M5.32675 13.6513H8.1723C9.18399 13.6513 10.0041 12.8311 10.0041 11.8194V6.0785H13.0351C13.4552 6.0889 13.7876 6.43759 13.7778 6.85777V11.5337C13.8365 14.0552 11.8417 16.1476 9.3203 16.2093C7.55824 16.1662 6.05333 15.1313 5.32675 13.6513Z" fill="#606060" />
                        <path d="M17.0197 3.4445C17.0197 4.45162 16.2033 5.26805 15.1962 5.26805C14.1891 5.26805 13.3726 4.45162 13.3726 3.4445C13.3726 2.43739 14.1891 1.62096 15.1962 1.62096C16.2033 1.62096 17.0197 2.43739 17.0197 3.4445Z" fill="#606060" />
                        <path d="M14.5819 13.7779C14.5382 13.7779 14.4948 13.7769 14.4516 13.775C14.7347 13.0807 14.8836 12.3186 14.8669 11.5217V6.86773C14.8712 6.58666 14.8124 6.31905 14.7036 6.0785H16.655C17.0803 6.0785 17.425 6.42321 17.425 6.84844V10.9482C17.425 12.511 16.1581 13.7779 14.5952 13.7779H14.5819Z" fill="#606060" />
                        <path d="M0.742786 3.64713H8.1723C8.58253 3.64713 8.91509 3.97969 8.91509 4.38991V11.8194C8.91509 12.2297 8.58253 12.5622 8.1723 12.5622H0.742786C0.332553 12.5622 0 12.2297 0 11.8194V4.38991C0 3.97969 0.332561 3.64713 0.742786 3.64713ZM6.41237 6.47484V5.69031H2.5027V6.47484H3.98098V10.5191H4.92719V6.47484H6.41237Z" fill="#606060" />
                      </svg>

                    )}
                    {tab}
                  </button>
                ))}
              </div>

              {activeTab === "Notes" && (
                <div className="flex flex-col flex-1 min-h-0 p-4 gap-4 overflow-hidden">
                  <textarea
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    placeholder="Add note"
                    className="w-full border border-[#EDEDED] rounded-xl p-3 text-[12px] text-[#838383] placeholder-[#C4C4D0] resize-none focus:outline-none focus:ring-1 focus:ring-[#F59E0B] focus:border-[#F59E0B] transition-all min-h-[158px]"
                  />
                  <div className="flex justify-end">
                    <button className="flex items-center gap-1.5 text-[10px] font-semibold text-[#303030] border border-[#FCA93D] rounded-full px-4 py-1.5 hover:bg-[#FFF8E7] transition-colors">
                      <span className="text-[14px] font-bold text-[#FCA93D]">+</span> Add Note
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3 flex-1">
                    {defaultNotes.map((note, i) => (
                      <NoteCard key={i} author={note.author} time={note.time} content={note.content} />
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "Document" && (
                <div className="flex-1 flex items-center justify-center p-8">
                  <div className="text-center text-[#9898AD]">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-3 opacity-40">
                      <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
                      <polyline points="13 2 13 9 20 9" />
                    </svg>
                    <p className="text-[13px]">No documents attached</p>
                  </div>
                </div>
              )}

              {activeTab === "Meeting" && (
                <div className="flex-1 flex items-center justify-center p-8">
                  <div className="text-center text-[#9898AD]">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-3 opacity-40">
                      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                      <line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" />
                      <line x1="3" y1="10" x2="21" y2="10" />
                    </svg>
                    <p className="text-[13px]">No meetings scheduled</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LeadOffcanvas;
