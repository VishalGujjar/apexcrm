import LeadRow from "./LeadRow";
import LeadOffCanvas from "./LeadOffCanvas";
import { useState } from "react";

const leads = [
  {
    id: 1,
    initials: "ML",
    color: "#EEF2FF",
    textColor: "#4F46E5",
    name: "Marty Lottenberg",
    email: "marty@omimex.com",
    company: "Microsoft",
    source: "Cold Call",
    status: "Closed Won",
    rep: "Sarah A.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "2h ago",
    score: 75,
    active: true,
  },
  {
    id: 2,
    initials: "JD",
    color: "#FEF3C7",
    textColor: "#92400E",
    name: "Jane Doe",
    email: "jane@microsoft.com",
    company: "Microsoft",
    source: "LinkedIn",
    status: "Contacted",
    rep: "Tom K.",
    repAvatar: "./src/assest/images/tom.png",
    lastActivity: "5h ago",
    score: 88,
    active: false,
  },
  {
    id: 3,
    initials: "JD",
    color: "#FEF3C7",
    textColor: "#92400E",
    name: "Jane Doe",
    email: "jane@microsoft.com",
    company: "Microsoft",
    source: "LinkedIn",
    status: "Contacted",
    rep: "Tom K.",
    repAvatar: "./src/assest/images/tom.png",
    lastActivity: "5h ago",
    score: 88,
    active: false,
  },
  {
    id: 4,
    initials: "CR",
    color: "#EFEFEF",
    textColor: "#991B1B",
    name: "Carlos Reyes",
    email: "c.reyes@finova.io",
    company: "Finova Inc.",
    source: "Webinar",
    status: "New",
    rep: "Sarah A.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "2d ago",
    score: 61,
    active: false,
  },
  {
    id: 5,
    initials: "AW",
    color: "#DCFCE7",
    textColor: "#166534",
    name: "Alice Wang",
    email: "alice.w@stripe.com",
    company: "Stripe",
    source: "Referral",
    status: "Qualified",
    rep: "Lisa M.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "1d ago",
    score: 92,
    active: false,
  },
  {
    id: 6,
    initials: "PN",
    color: "#F3E8FF",
    textColor: "#7E22CE",
    name: "Priya Nair",
    email: "priya@cloudzap.ai",
    company: "CloudZap AI",
    source: "Inbound",
    status: "Closed Won",
    rep: "Tom K.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "3d ago",
    score: 96,
    active: false,
  },
  {
    id: 7,
    initials: "LS",
    color: "#EFEFEF",
    textColor: "#0369A1",
    name: "Lucas Schmidt",
    email: "l.schmidt@deinbank.de",
    company: "DeinBank GmbH",
    source: "Cold Email",
    status: "Contacted",
    rep: "Lisa M.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "4d ago",
    score: 55,
    active: false,
  },
  {
    id: 8,
    initials: "CR",
     color: "#EFEFEF",
     textColor: "#991B1B",
    name: "Carlos Reyes",
    email: "c.reyes@finova.io",
    company: "Finova Inc.",
    source: "Webinar",
    status: "New",
    rep: "Sarah A.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "2d ago",
    score: 61,
    active: false,
  },
  {
    id: 9,
    initials: "CR",
    color: "#EFEFEF",
    textColor: "#991B1B",
    name: "Carlos Reyes",
    email: "c.reyes@finova.io",
    company: "Finova Inc.",
    source: "Webinar",
    status: "New",
    rep: "Sarah A.",
    repAvatar: "./src/assest/images/sarah.png",
    lastActivity: "2d ago",
    score: 61,
    active: false,
  },
];

const columns = [
  "Lead",
  "Company",
  "Source",
  "Status",
  "Assigned Rep",
  "Last Activity",
  "Score",
  "Actions"
];

export default function LeadsTable() {
  const [selectedLead, setSelectedLead] = useState(null);
  const [isOffCanvasOpen, setIsOffCanvasOpen] = useState(false);

  const handleRowClick = (lead) => {
    setSelectedLead(lead);
    setIsOffCanvasOpen(true);
  };

  const handleCloseOffCanvas = () => {
    setIsOffCanvasOpen(false);
    setSelectedLead(null);
  };

  return (
    <div className="mx-6 mt-3 bg-white rounded-[14px] shadow-sm border border-[#EDEDED]">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <div className="flex items-center gap-1">
          {["All Leads", "Mine", "Unassigned"].map((tab, i) => (
            <button
              key={tab}
              className={`px-3 py-1.5 text-12 font-medium rounded-md transition-all ${i === 0
                  ? "bg-[#EEF2FF] text-[#4F46E5] shadow-sm"
                  : "text-graytext-200 hover:text-gray-700"
                }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <span className="text-11 text-[#9898AD] font-medium">7 leads</span>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-11 font-medium text-gray-600 border border-[#EDEDED] rounded-[10px] bg-white hover:bg-gray-50 transition-colors">
            <img src="/src/assest/images/export.svg" alt="Apex CRM" className="" />
            Export
          </button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-b-[#EDEDED] bg-[#FCFBF8]">
              <th className="py-2 pl-4 pr-2 w-8">
                <input
                  type="checkbox"
                  className="rounded border-[#757575] text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
                />
              </th>
              {columns.map((col) => (
                <th
                  key={col}
                  className="py-3 px-3 text-11 font-bold uppercase tracking-wider text-[#9898AD] whitespace-nowrap"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {leads.map((lead) => (
              <LeadRow 
                key={lead.id} 
                lead={lead} 
                active={lead.active} 
                onClick={() => handleRowClick(lead)}
              />
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Lead OffCanvas */}
      <LeadOffCanvas 
        open={isOffCanvasOpen} 
        onClose={handleCloseOffCanvas} 
        lead={selectedLead} 
      />
    </div>
  );
}
