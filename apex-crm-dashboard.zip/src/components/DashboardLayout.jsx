import Sidebar from "./Sidebar";
import Header from "./Header";
import StatsCards from "./StatsCards";
import FiltersBar from "./FiltersBar";
import LeadsTable from "./LeadsTable";
import RightPanel from "./RightPanel";

export default function DashboardLayout() {
  return (
    <div className="min-h-screen bg-[#F5F5F7] flex">
      {/* Left Sidebar */}
      <Sidebar />
      {/* Main Content */}
      <div className="flex-1 ml-56 flex flex-col min-h-screen">
        <Header />
        <main className="grid grid-cols-12 pb-8 me-6">
          <div className="col-span-9">
            <StatsCards />
            <FiltersBar />
            <LeadsTable />
          </div>
          <div className="col-span-3">
          <RightPanel />
          </div>
        </main>
      </div>
    </div>
  );
}
