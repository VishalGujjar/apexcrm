
const statusStyles = {
  "Closed Won": "bg-[#166534]/10 text-[#166534]",
  Contacted: "bg-[#0284C7]/10 text-[#0284C7]",
  New: "bg-[#4338CA]/10 text-[#4338CA]",
  Qualified: "bg-[#16A34A]/10 text-[#16A34A]",
};

const scoreBarColor = (score) => {
  if (score >= 90) return "bg-emerald-500";
  if (score >= 70) return "bg-indigo-500";
  if (score >= 50) return "bg-amber-400";
  return "bg-red-400";
};

export default function LeadRow({ lead, active, onClick }) {
  return (
    <tr
      className={`border-b border-b-[#EDEDED] hover:bg-[#EEF2FF] transition-colors cursor-pointer ${
        active ? "bg-[#EEF2FF]" : ""
      }`}
      onClick={onClick}
    >
      <td className="py-3 pl-4 pr-2">
        <input
          type="checkbox"
          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
        />
      </td>
      <td className="py-3 px-3">
        <div className="flex items-center gap-3">
          <div
            className="w-[28px] h-[28px] rounded-full text-10 font-semibold flex items-center justify-center flex-shrink-0"
            style={{ 
              backgroundColor: lead.color,
              color: lead.textColor || 'white',
            }}
          >
            {lead.initials}
          </div>
          <div>
            <p className="text-13 font-semibold text-graytext-300 leading-tight">
              {lead.name}
            </p>
            <p className="text-11 text-[#9898AD]">{lead.email}</p>
          </div>
        </div>
      </td>
      <td className="py-3 px-3">
        <span className="text-12 text-graytext-200">{lead.company}</span>
      </td>
      <td className="py-3 px-3">
        <span
          className="inline-block text-graytext-200 whitespace-nowrap dm-mono text-11 border border-[#EDEDED] font-medium px-2.5 py-1 rounded-md bg-[#F5F5F7]"
        >
          {lead.source}
        </span>
      </td>
      <td className="py-3 px-3">
        <span
          className={`inline-block text-11 font-semibold whitespace-nowrap px-2.5 py-1 rounded-full ${
            statusStyles[lead.status] || "bg-gray-100 text-gray-500"
          }`}
        >
          {lead.status}
        </span>
      </td>
      <td className="py-3 px-3">
        <div className="flex items-center gap-2">
          <img
            src={lead.rep === "Sarah" ? "/src/assest/images/sarah.png" : lead.rep === "Tom" ? "/src/assest/images/tom.png" : lead.repAvatar}
            alt={lead.rep}
            className="w-6 h-6 rounded-full object-cover"
          />
          <div
            className="w-6 h-6 rounded-full bg-gray-300 text-gray-600 text-[9px] font-bold items-center justify-center hidden"
          >
            {lead.rep.split(" ").map((n) => n[0]).join("")}
          </div>
          <span className="text-11 text-graytext-200">{lead.rep}</span>
        </div>
      </td>
      <td className="py-3 px-3">
        <span className="text-12 text-[#9898AD]">{lead.lastActivity}</span>
      </td>
      <td className="py-3 px-3">
        <div className="flex items-center gap-2">
          <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${scoreBarColor(lead.score)}`}
              style={{ width: `${lead.score}%` }}
            ></div>
          </div>
          <span className="text-11 font-semibold text-graytext-200 w-6 text-right">
            {lead.score}
          </span>
        </div>
      </td>
      <td className="py-3 px-3">
        <div className="flex gap-1 items-center">
         <button className="relative p-2 w-[27px] h-[27px] bg-white rounded-[10px] hover:bg-gray-100 border border-[#E0E0E0] transition-colors text-gray-400 hover:text-gray-600">
          <img src="/src/assest/images/eye.svg" alt="Apex CRM" className="" />
        </button>
         <button className="relative bg-white w-[27px] h-[27px] p-2 rounded-[10px] hover:bg-gray-100 border border-[#E0E0E0] transition-colors text-gray-400 hover:text-gray-600">
          <img src="/src/assest/images/edit.svg" alt="Apex CRM" className="" />
        </button>
         <button className="relative bg-white w-[27px] h-[27px] p-2 rounded-[10px] hover:bg-gray-100 border border-[#E0E0E0] transition-colors text-gray-400 hover:text-gray-600">
          <img src="/src/assest/images/option.svg" alt="Apex CRM" className="" />
        </button>
        </div>
      </td>
    </tr>
  );
}
