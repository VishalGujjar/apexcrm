const dropdowns = ["Status", "Assigned Rep", "Source", "Date range"];

export default function FiltersBar() {
  return (
    // filter design component
    <div className="px-6 pt-4 space-y-3">
      <div className="bg-white rounded-[14px] p-3 border border-[#EDEDED]">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-sm">
            <svg
              className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9898AD]"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            <input
              type="text"
              placeholder="Search leads, companies..."
              className="w-full pl-9 pr-4 py-2 text-13 border border-[#EDEDED] rounded-[10px] bg-[#F5F5F7] text-gray-700 placeholder-[#9898AD] focus:outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300 transition-all"
            />
          </div>

          <div className="flex items-center gap-2">
            {dropdowns.map((label) => (
              <button
                key={label}
                className="flex items-center gap-1.5 px-3 py-2 text-13 font-medium text-graytext-200 bg-white border border-[#EDEDED] rounded-[10px] hover:bg-gray-50 transition-colors"
              >
                {label}
                <svg className="w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            ))}

            <div className="w-px h-5 bg-gray-200 mx-1" />

            <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-graytext-300 bg-white border border-[#EDEDED] rounded-[10px] hover:bg-gray-50 transition-colors">
              <img src="/src/assest/images/sort.svg" alt="Apex CRM" className="" />
              Sort
            </button>

            <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-graytext-300 bg-white border border-[#EDEDED] rounded-[10px] hover:bg-gray-50 transition-colors">
              <img src="/src/assest/images/filter.svg" alt="Apex CRM" className="" />
              Filter
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}
