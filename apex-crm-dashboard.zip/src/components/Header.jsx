export default function Header() {
  return (
    // Header design component
    <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-[#EDEDED] w-full">
      <div className="flex gap-[10px] items-center ">
        <div className="pe-4">
          <h1 className="text-base font-bold text-graytext-300 tracking-tight">Leads</h1>
          <div className="flex items-center gap-2 text-11 text-graytext-100 mb-1">
            <span>Sales</span>
            <span>/</span>
            <span>Leads</span>
            <span>
              124 total
            </span>
          </div>
        </div>
        <p className="text-xs text-graytext-100 border-l border[#EDEDED] ps-4">Last updated 2 min ago</p>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative p-2 rounded-[10px] hover:bg-gray-100 border border-[#E0E0E0] transition-colors text-gray-400 hover:text-gray-600">
          <img src="/src/assest/images/notiifcation.svg" alt="Apex CRM" className="" />
        </button>
        <button className="flex items-center gap-2 px-4 py-2 text-12 font-medium text-graytext-300 border border-gray-200 rounded-[10px] hover:bg-gray-50 transition-colors">
          <img src="/src/assest/images/import.svg" alt="Apex CRM" className="" />
          Import
        </button>
        <button className="flex items-center gap-2 px-4 py-2 text-12 font-medium text-white bg-[#4F46E5] hover:bg-indigo-700 rounded-[10px] transition-colors shadow-sm">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Add Lead
        </button>
      </div>
    </header>
  );
}
