const navItems = [
  { label: "Overview", icon: "/src/assest/images/overview.svg" },
  { label: "Leads", icon: "☰", active: true, count: 124 },
  { label: "Contacts", icon: "/src/assest/images/contact.svg" },
  { label: "Deals", icon: "/src/assest/images/deals.svg" },
  { label: "Pipeline", icon: "/src/assest/images/pipeline.svg" },
];

const insightItems = [
  { label: "Analytics", icon: "/src/assest/images/analytics.svg" },
  { label: "Reports", icon: "/src/assest/images/reports.svg" },
];

const teamItems = [
  { label: "Team", icon: "/src/assest/images/team.svg" },
  { label: "Settings", icon: "/src/assest/images/setting.svg" },
];

function NavItem({ icon, label, active, count }) {
  return (
    <li>
      <button
        className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-13 font-medium transition-colors ${active
            ? "bg-[#EEF2FF] text-iris-500"
            : "text-gray-500 hover:bg-gray-100 hover:text-gray-700"
          }`}
      >
        <span className="flex items-center gap-3">
          {icon.startsWith('/') ? (
            <img src={icon} alt={label} className="w-5 h-5" />
          ) : (
            <span className="text-base leading-none">{icon}</span>
          )}
          {label}
        </span>
        {count && (
          <span className="text-10 text-iris-500 font-semibold">
            {count}
          </span>
        )}
      </button>
    </li>
  );
}

export default function Sidebar() {
  return (
    // sidebar component design
    <aside className="fixed top-0 left-0 h-screen w-56 bg-white border-r border-[#EDEDED] flex flex-col z-20">
      <div className="px-4 py-5 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <img src="/src/assest/images/icon-apex.svg" alt="Apex CRM" className="" />
          <span className="text-sm font-semibold text-iris-500 ">
            Apex <span className="font-light text-graytext-300">CRM</span>
          </span>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-graytext-200 px-3 mb-2">
            Sales
          </p>
          <ul className="space-y-0.5">
            {navItems.map((item) => (
              <NavItem key={item.label} {...item} />
            ))}
          </ul>
        </div>

        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-graytext-200 px-3 mb-2">
            Insights
          </p>
          <ul className="space-y-0.5">
            {insightItems.map((item) => (
              <NavItem key={item.label} {...item} />
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-graytext-200 px-3 mb-2">
            Team
          </p>
          <ul className="space-y-0.5">
            {teamItems.map((item) => (
              <NavItem key={item.label} {...item} />
            ))}
          </ul>
        </div>
      </nav>
      <div className="px-4 py-4 border-t border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-[28px] h-[28px] rounded-full bg-[#EEF2FF] text-iris-500 text-10 font-semibold flex items-center justify-center flex-shrink-0">
            SA
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-graytext-300 truncate">
              Sarah Adams
            </p>
            <p className="text-11 text-[#9898AD] truncate">Sales Manager</p>
          </div>
          <button className="ml-auto text-[#9898AD] hover:text-gray-500 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </aside>
  );
}
