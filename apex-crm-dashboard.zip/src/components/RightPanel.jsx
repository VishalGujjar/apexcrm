const lead = {
  name: "Marty Lottenberg",
  title: "CEO · Omimex Canada Ltd",
  initials: "ML",
  email: "marty@omimex.com",
  phone: "+1 911 120 222",
  source: "Cold Call",
  status: "New",
  dealValue: "$48,000",
  score: 75,
  engagement: "High",
  fitScore: "82%",
  activities: [
    {
      label: "Email opened: Q2 Proposal",
      time: "2 hours ago",
      color: "bg-[#818CF8]",
    },
    {
      label: "Call logged — 14 min duration",
      time: "Yesterday",
      color: "bg-[#34D399]",
    },
  ],
};

function ScoreRing({ score }) {
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center pt-5">
      <div className="relative w-28">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke="#f3f4f6"
            strokeWidth="10"
          />
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke="#6366f1"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-700"
          />
        </svg>
        <div className="flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-indigo-600">{score}</span>
        </div>
      </div>
      <p className="text-11 text-[#9898AD] mt-1 font-medium">Lead Score</p>

      <div className="flex mt-3 w-full justify-center border-t border-[#EDEDED]">
        <div className="border-l border-[#EDEDED] py-2 px-2 w-full  border-r border-r-[#EDEDED]"> 
          <p className="text-11 text-[#9898AD]">Engagement</p>
          <p className="text-13 font-bold text-[#16A34A]">{lead.engagement}</p>
        </div>
        <div className="py-2 px-2 w-full">
          <p className="text-11 text-[#9898AD]">Fit score</p>
          <p className="text-13 font-bold text-[#4F46E5]">{lead.fitScore}</p>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value, highlight }) {
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-[#EDEDED] px-4">
      <span className="text-11 text-[#9898AD] font-medium">{label}</span>
      <span
        className={`text-11 font-semibold ${
          highlight === "email"
            ? "text-[#4F46E5]"
            : highlight === "status"
            ? "bg-[#EEF2FF] text-[#4338CA] px-2 py-0.5 rounded-full"
            : "text-graytext-300"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

export default function RightPanel() {
  return (
    <>
    <aside>
    <div className="bg-white border border-[#EDEDED] rounded-[10px] z-10 mt-4 pb-3">
      <div className=" py-4">
        <p className="text-[10px] px-4 font-bold uppercase tracking-widest text-graytext-100 mb-3">
          Lead Preview
        </p>
        <div className=" px-4 flex items-center gap-3 pb-4 border-b border-[#EDEDED]">
          <div className="w-10 h-10 rounded-full bg-[#EEF2FF] text-[#4F46E5] text-13 font-bold flex items-center justify-center flex-shrink-0">
            {lead.initials}
          </div>
          <div>
            <p className="text-15 font-bold text-graytext-300 leading-tight">{lead.name}</p>
            <p className="text-12 text-graytext-200">{lead.title}</p>
          </div>
        </div>
        <div className="">
          <InfoRow label="Email" value={lead.email} highlight="email" />
          <InfoRow label="Phone" value={lead.phone} />
          <InfoRow label="Source" value={lead.source} />
          <InfoRow label="Status" value={lead.status} highlight="status" />
          <InfoRow label="Deal value" value={lead.dealValue} />
        </div>
      </div>
      <div className="px-4 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <button className="flex items-center justify-center gap-1.5 py-2 bg-indigo-600 text-white text-11 font-semibold rounded-lg hover:bg-indigo-700 transition-colors">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            Email
          </button>
          <button className="flex items-center justify-center gap-1.5 py-2 bg-white border border-gray-200 text-gray-600 text-11 font-semibold rounded-lg hover:bg-gray-50 transition-colors">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            Note
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button className="flex items-center justify-center gap-1.5 py-2 bg-white border border-gray-200 text-gray-600 text-11 font-semibold rounded-lg hover:bg-gray-50 transition-colors">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Task
          </button>
          <button className="flex items-center justify-center gap-1.5 py-2 bg-white border border-gray-200 text-gray-600 text-11 font-semibold rounded-lg hover:bg-gray-50 transition-colors">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
            Full view
          </button>
        </div>
      </div>

    </div>
      <div className="pt-3 bg-white border border-[#EDEDED] rounded-[10px] z-10 mt-4 pb-0">
        <p className="px-3 text-[10px] font-bold uppercase pb-2 tracking-widest text-graytext-100 border-b border-b-[#EDEDED]">
          AI Lead Score
        </p>
        <ScoreRing score={lead.score} />
      </div>
      <div className="pt-3 bg-white border border-[#EDEDED] rounded-[10px] z-10 mt-4 pb-0">
        <p className="px-3 text-[10px] font-bold uppercase pb-2 tracking-widest text-graytext-100 border-b border-b-[#EDEDED]">
          Recent Activity
        </p>
        <div className="space-y-3">
          {lead.activities.map((activity, i) => (
            <div key={i} className="flex items-start gap-3 py-2 px-2 border-b border-b-[#EDEDED]">
              <div className={`w-2 h-2 rounded-full ${activity.color} mt-1.5 flex-shrink-0`}></div>
              <div>
                <p className="text-12 font-medium text-graytext-200 leading-snug">
                  {activity.label}
                </p>
                <p className="text-[10px] dm-mono text-[#9898AD] mt-0.5">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      </aside>
      </>
  );
}
